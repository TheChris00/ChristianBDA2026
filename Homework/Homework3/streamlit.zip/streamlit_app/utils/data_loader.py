

import streamlit as st
import pandas as pd
from pathlib import Path

DATA = Path(__file__).parent.parent / "data"


@st.cache_data 
def load_star():

    # read the 5 csv, merge the 4 keys, filtered BUY/SELL retunring the dataframe
    fact = pd.read_csv(DATA / "fact_transactions.csv")
    dim_time = pd.read_csv(DATA / "dim_time.csv", parse_dates =["date"])
    dim_symbol = pd.read_csv(DATA / "dim_symbol.csv")
    dim_geography = pd.read_csv(DATA / "dim_geography.csv")
    dim_transactiontype = pd.read_csv(DATA / "dim_transactiontype.csv")
    #the other 3 dimensions

    star = (fact
            .merge(dim_time, on="time_sk")
            .merge(dim_symbol, on="symbol_sk")
            .merge(dim_geography, on="geo_sk")
            .merge(dim_transactiontype, on="type_sk"))
    
    # keep only trading transactions (BUY / SELL)
    star = star[star["transaction_type"].isin(["BUY", "SELL"])]

    return star