
import streamlit as st

st.set_page_config(page_title = "Financial Transactions", layout = "wide")

st.title("Financial Transactions Dashboard")
st.write("Use the menu on the left to navigate to the pages")