from datetime import date
import streamlit as st
import pandas as pd
from utils.data_loader import load_star

st.set_page_config(page_title="Time Analysis", layout="wide")
st.title("Time Analysis")

star = load_star()

# the filter


date_range = st.date_input(
    "Date range",
    value=(date(2024, 1, 1), date(2024, 12, 31)),
    min_value=date(2024, 1, 1),
    max_value=date(2024, 12, 31),
)

# date_input returns a tuple, holding only 1 element
if isinstance(date_range, tuple) and len(date_range) == 2:
    start, end = date_range
else:
    start = end = date_range if not isinstance(date_range, tuple) else date_range[0]

# single filter, all charts use 'd'
mask = (star["date"].dt.date >= start) & (star["date"].dt.date <= end)
d = star[mask]

if d.empty:
    st.warning("No transactions in the selected date range.")
else:
    # Chart 1: line chart, total transactions (BUY+SELL) over time
    st.subheader("Total transactions over time")
    over_time = d.groupby(d["date"].dt.date).size()
    st.line_chart(over_time)

    # Chart 2: top 3 symbols by transaction count
    st.subheader("Top 3 traded symbols")
    top_symbols = d.groupby("symbol").size().sort_values(ascending=False).head(3)
    st.bar_chart(top_symbols)

    # two charts side by side
    left, right = st.columns(2)

    # Chart 3: top 5 sectors
    with left:
        st.subheader("Top 5 sectors")
        top_sectors = d.groupby("sector").size().sort_values(ascending=False).head(5)
        st.bar_chart(top_sectors)

    # Chart 4: top 5 industries
    with right:
        st.subheader("Top 5 industries")
        top_industries = d.groupby("industry").size().sort_values(ascending=False).head(5)
        st.bar_chart(top_industries)